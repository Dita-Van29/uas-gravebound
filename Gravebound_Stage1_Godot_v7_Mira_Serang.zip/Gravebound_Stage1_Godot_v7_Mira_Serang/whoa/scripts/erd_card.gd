extends PanelContainer
## Kartu Atribut yang bisa diseret (drag and drop) ke entitas di Panel Entitas.
## source = "tray" (dari kolom kartu) atau "entity" (sudah terpasang di sebuah entitas).

const UI := preload("res://scripts/ui_kit.gd")

var attr_name: String = ""
var attr_value: String = ""
var source: String = "tray"
var glow: bool = false


func setup(a_name: String, a_value: String, a_glow: bool = false, a_source: String = "tray") -> void:
	attr_name = a_name
	attr_value = a_value
	glow = a_glow
	source = a_source
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_DRAG
	var border: Color = UI.GOLD if glow else Color(0.4, 0.32, 0.68)
	add_theme_stylebox_override("panel", UI.style(Color(0.17, 0.12, 0.28, 1.0), border, 8.0, 3 if glow else 2))
	var v := VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(v)
	if glow:
		v.add_child(UI.label("BARU - seret aku!", 12, UI.GOLD))
	v.add_child(UI.label(attr_name, 18, Color.WHITE))
	if attr_value != "":
		v.add_child(UI.wrap_label(attr_value, 190.0, 13, UI.MUTED))


func _get_drag_data(_at_position: Vector2) -> Variant:
	var prev := PanelContainer.new()
	prev.add_theme_stylebox_override("panel", UI.style(Color(0.27, 0.19, 0.48, 0.95), UI.GOLD, 8.0, 2))
	prev.add_child(UI.label(attr_name, 18, UI.GOLD))
	set_drag_preview(prev)
	return {"attr": attr_name, "value": attr_value, "source": source}

extends CanvasLayer
## ARSIP JIWA - MODE DESAIN (ERD).
## Pemain merancang ERD dengan drag and drop. Dua pelajaran terpandu + satu mode lihat:
##   "skill" : seret Kartu Atribut `skill` ke entitas PLAYER (Raise terbuka), lalu pilih primary key.
##   "split" : seret `daftar_shade` ke PLAYER, pecahkan menjadi entitas SHADE, pilih kardinalitas 1 : N.
##   "view"  : lihat ERD yang sudah dirancang (tombol Tab atau G).
## Salah itu aman: Pip memberi petunjuk bertahap (3 tingkat). Makin sedikit petunjuk, makin banyak bintang.

signal closed

const UI := preload("res://scripts/ui_kit.gd")
const CardScript := preload("res://scripts/erd_card.gd")
const DropScript := preload("res://scripts/erd_drop.gd")
const RelScript := preload("res://scripts/erd_relation.gd")

const HINTS := {
	"skill": [
		"Kartu itu adalah atribut. Atribut selalu menempel pada satu entitas. Siapa yang memakai skill?",
		"Skill dipakai oleh Mira. Cari kotak entitas PLAYER, lalu lepaskan kartunya di sana.",
		"Seret kartu 'skill' dari kolom kiri dan lepaskan di kotak PLAYER.",
	],
	"pk": [
		"Primary key adalah atribut yang nilainya unik dan tidak berubah untuk setiap baris.",
		"Nama bisa kembar, dan essence terus berubah. Atribut mana yang pasti berbeda untuk tiap pemain?",
		"Jawabannya id_player.",
	],
	"daftar": [
		"Kartu daftar_shade juga sebuah atribut. Entitas mana yang memiliki pasukan Shade?",
		"Pasukan Shade milik Mira, jadi pasang kartu ini ke entitas PLAYER dulu.",
		"Seret kartu daftar_shade ke kotak PLAYER.",
	],
	"split": [
		"Satu atribut yang menampung banyak nilai tidak boleh dibiarkan. Pecahkan menjadi entitas sendiri.",
		"Seret baris daftar_shade keluar dari PLAYER, lalu lepaskan di kotak entitas baru di sebelah kanan.",
		"Seret kartu daftar_shade (yang ada di dalam PLAYER) ke kotak SHADE.",
	],
	"card": [
		"Hitung dari dua arah: satu Mira punya berapa Shade? Satu Shade dimiliki berapa Mira?",
		"Satu Mira bisa memiliki banyak Shade, tetapi satu Shade hanya milik satu Mira.",
		"Jawabannya 1 : N.",
	],
}

const GLOSSARY := [
	["Entitas", "Objek yang datanya disimpan, misalnya PLAYER dan SHADE."],
	["Atribut", "Keterangan milik entitas, misalnya nama dan hp_maks."],
	["Primary key (PK)", "Atribut unik yang mengenali satu baris."],
	["Foreign key (FK)", "Atribut yang menunjuk PK milik entitas lain."],
	["Relasi", "Hubungan antar entitas, misalnya PLAYER memiliki SHADE."],
	["Kardinalitas", "Jumlah hubungan: 1 : 1, 1 : N, atau N : M."],
]

var stage = null

var _root: ColorRect
var _tray: VBoxContainer
var _tray_title: Label
var _player_zone
var _player_rows: VBoxContainer
var _shade_zone
var _shade_title: Label
var _shade_rows: VBoxContainer
var _rel
var _step_label: Label
var _pip_label: Label
var _question: VBoxContainer
var _stars_label: Label
var _close_btn: Button

var _mode: String = "view"
var _step: String = ""
var _hints: int = 0
var _wrong: Dictionary = {}
var _daftar_in_player: bool = false
var _shade_created: bool = false
var _finished: bool = false


func _ready() -> void:
	layer = 12
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	_root.visible = false


# ------------------------------------------------------------------ API publik
func is_open() -> bool:
	return _root != null and _root.visible


func run_skill_lesson() -> void:
	_start("skill")
	await closed


func run_split_lesson() -> void:
	_start("split")
	await closed


func open_viewer() -> void:
	_start("view")
	await closed


# ------------------------------------------------------------------ Build UI
func _build() -> void:
	_root = ColorRect.new()
	_root.color = Color(0.02, 0.0, 0.05, 0.84)
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 40)
	margin.add_theme_constant_override("margin_right", 40)
	margin.add_theme_constant_override("margin_top", 26)
	margin.add_theme_constant_override("margin_bottom", 26)
	_root.add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var main := UI.panel()
	margin.add_child(main)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	main.add_child(col)

	# Judul
	var head := HBoxContainer.new()
	col.add_child(head)
	var title := UI.label("Arsip Jiwa  -  Mode Desain (ERD)", 28, UI.GOLD)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	head.add_child(UI.label("Stage 1: Desa Lumen", 16, UI.MUTED))

	_step_label = UI.label("", 19, UI.CYAN)
	col.add_child(_step_label)

	# Isi: kolom kartu | kanvas | Pip
	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 12)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(body)

	var tray_panel := UI.panel(Color(0.1, 0.07, 0.18, 1.0), UI.BORDER, 10.0)
	tray_panel.custom_minimum_size = Vector2(250, 0)
	body.add_child(tray_panel)
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", 8)
	tray_panel.add_child(tv)
	_tray_title = UI.label("Kartu Atribut", 20, UI.CYAN)
	tv.add_child(_tray_title)
	_tray = VBoxContainer.new()
	_tray.add_theme_constant_override("separation", 8)
	tv.add_child(_tray)

	var canvas := UI.panel(Color(0.08, 0.06, 0.15, 1.0), UI.BORDER, 12.0)
	canvas.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(canvas)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 10)
	canvas.add_child(cv)

	var ents := HBoxContainer.new()
	ents.alignment = BoxContainer.ALIGNMENT_CENTER
	ents.add_theme_constant_override("separation", 6)
	cv.add_child(ents)

	_player_zone = DropScript.new()
	_player_zone.custom_minimum_size = Vector2(250, 290)
	_player_zone.drop_fn = _on_drop_player
	ents.add_child(_player_zone)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 4)
	_player_zone.add_child(pv)
	pv.add_child(UI.label("PLAYER", 22, Color.WHITE))
	_player_rows = VBoxContainer.new()
	_player_rows.add_theme_constant_override("separation", 3)
	pv.add_child(_player_rows)

	_rel = RelScript.new()
	_rel.setup("1", "N", "memiliki")
	_rel.visible = false
	ents.add_child(_rel)

	_shade_zone = DropScript.new()
	_shade_zone.custom_minimum_size = Vector2(250, 290)
	_shade_zone.drop_fn = _on_drop_shade
	ents.add_child(_shade_zone)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 4)
	_shade_zone.add_child(sv)
	_shade_title = UI.label("SHADE", 22, Color.WHITE)
	sv.add_child(_shade_title)
	_shade_rows = VBoxContainer.new()
	_shade_rows.add_theme_constant_override("separation", 3)
	sv.add_child(_shade_rows)

	_question = VBoxContainer.new()
	_question.add_theme_constant_override("separation", 8)
	cv.add_child(_question)

	# Pip
	var pip_panel := UI.panel(Color(0.1, 0.07, 0.18, 1.0), UI.BORDER, 10.0)
	pip_panel.custom_minimum_size = Vector2(270, 0)
	body.add_child(pip_panel)
	var pipv := VBoxContainer.new()
	pipv.add_theme_constant_override("separation", 8)
	pip_panel.add_child(pipv)
	var ph := HBoxContainer.new()
	pipv.add_child(ph)
	var tr := TextureRect.new()
	tr.texture = Util.load_tex("res://assets/sprites/pip.png")
	tr.custom_minimum_size = Vector2(52, 52)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ph.add_child(tr)
	ph.add_child(UI.label("  Pip", 22, UI.GOLD))
	_pip_label = UI.wrap_label("", 240.0, 16, Color(0.95, 0.93, 1.0))
	pipv.add_child(_pip_label)
	_stars_label = UI.wrap_label("", 240.0, 17, UI.GREEN)
	pipv.add_child(_stars_label)

	# Kaki
	var foot := HBoxContainer.new()
	col.add_child(foot)
	var legend := UI.label("PK = primary key      FK = foreign key      Esc / Tab / G = tutup (saat selesai)", 14, UI.MUTED)
	legend.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	foot.add_child(legend)
	_close_btn = UI.button("Tutup", Vector2(180, 42), 18)
	_close_btn.pressed.connect(_on_close)
	foot.add_child(_close_btn)


# ------------------------------------------------------------------ Alur pelajaran
func _start(mode: String) -> void:
	_mode = mode
	_hints = 0
	_wrong.clear()
	_finished = false
	_daftar_in_player = false
	_shade_created = GameState.erd_split_done
	_stars_label.text = ""
	if mode == "skill":
		_close_btn.visible = false
		_set_step("skill")
		_say_pip("Atribut itu harus tercatat pada satu entitas. Seret kartu skill ke entitas yang memakainya.")
	elif mode == "split":
		_close_btn.visible = false
		_set_step("daftar")
		_say_pip("Soul Bank-mu mulai penuh. Kartu daftar_shade menampung semua Shade. Pasang dulu ke entitas pemiliknya.")
	else:
		_close_btn.visible = true
		_close_btn.text = "Tutup"
		_set_step("view")
		if GameState.erd_split_done:
			_say_pip("ERD-mu sudah rapi: PLAYER memiliki banyak SHADE (1 : N). Setiap Shade punya PK sendiri dan FK yang menunjuk pemiliknya.")
		else:
			_say_pip("Ini ERD milik Mira sejauh ini. Daftar Shade akan dirapikan setelah Area 1 selesai.")
	_refresh()
	_root.visible = true


func _set_step(s: String) -> void:
	_step = s
	match s:
		"skill":
			_step_label.text = "Langkah 1: seret kartu 'skill' ke entitas PLAYER."
		"pk":
			_step_label.text = "Langkah 2: pilih primary key untuk PLAYER."
		"daftar":
			_step_label.text = "Langkah 1: seret kartu 'daftar_shade' ke entitas PLAYER."
		"split":
			_step_label.text = "Langkah 2: seret baris 'daftar_shade' keluar dari PLAYER ke kotak entitas baru."
		"card":
			_step_label.text = "Langkah 3: pilih kardinalitas relasi PLAYER - SHADE."
		"done":
			_step_label.text = "Selesai! Kamu merancang ERD dengan benar."
		_:
			_step_label.text = "Mode lihat: ERD yang sudah kamu rancang."
	_build_question(s)


func _say_pip(text: String) -> void:
	_pip_label.text = text


func _hint(step: String, extra: String = "") -> void:
	_hints += 1
	var arr: Array = HINTS[step]
	var i: int = mini(int(_wrong.get(step, 0)), arr.size() - 1)
	_wrong[step] = int(_wrong.get(step, 0)) + 1
	if extra != "":
		_say_pip(extra)
	else:
		_say_pip(String(arr[i]))
	_stars_label.text = "Petunjuk dipakai: %d" % _hints


# ------------------------------------------------------------------ Drop handler
func _on_drop_player(data) -> void:
	if _finished or _mode == "view":
		return
	var a: String = String(data.get("attr", ""))
	var src: String = String(data.get("source", ""))
	if _step == "skill":
		if a == "skill":
			GameState.erd_skill_done = true
			_say_pip("Betul! Atribut skill kini tercatat di PLAYER, jadi Raise terbuka. Berikutnya, tentukan primary key PLAYER.")
			_set_step("pk")
		else:
			_hint("skill")
	elif _step == "daftar":
		if a == "daftar_shade" and src == "tray":
			_daftar_in_player = true
			_say_pip("Perhatikan: satu atribut kini menampung banyak nilai (atribut multivalue). Itu tidak rapi. Pecahkan menjadi entitas sendiri!")
			_set_step("split")
		else:
			_hint("daftar")
	elif _step == "split":
		_hint("split")
	else:
		_hint("skill")
	_refresh.call_deferred()


func _on_drop_shade(data) -> void:
	if _finished or _mode == "view":
		return
	var a: String = String(data.get("attr", ""))
	var src: String = String(data.get("source", ""))
	if _step == "split":
		if a == "daftar_shade" and src == "entity":
			_daftar_in_player = false
			_shade_created = true
			_say_pip("Entitas baru SHADE terbentuk! Setiap Shade kini punya baris sendiri. Terakhir, tentukan kardinalitas relasinya.")
			_set_step("card")
		else:
			_hint("split")
	elif _step == "daftar":
		_hint("daftar")
	else:
		_hint("skill", "Entitas SHADE belum ada. Atribut skill milik Mira, jadi lepaskan di PLAYER.")
	_refresh.call_deferred()


# ------------------------------------------------------------------ Pertanyaan pilihan
func _build_question(step: String) -> void:
	UI.clear_children(_question)
	if step == "pk":
		_question.add_child(UI.label("Atribut mana yang paling cocok jadi primary key PLAYER?", 18, UI.GOLD))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		for opt in ["id_player", "nama", "essence"]:
			var b := UI.button(opt, Vector2(150, 42), 17)
			b.pressed.connect(_on_pk_choice.bind(opt))
			row.add_child(b)
		_question.add_child(row)
	elif step == "card":
		_question.add_child(UI.label("Satu Mira bisa punya banyak Shade, dan satu Shade milik berapa Mira? Pilih kardinalitasnya:", 18, UI.GOLD))
		var row2 := HBoxContainer.new()
		row2.add_theme_constant_override("separation", 10)
		for opt2 in ["1 : 1", "1 : N", "N : M"]:
			var b2 := UI.button(opt2, Vector2(130, 42), 18)
			b2.pressed.connect(_on_card_choice.bind(opt2))
			row2.add_child(b2)
		_question.add_child(row2)


func _on_pk_choice(opt: String) -> void:
	if _finished:
		return
	if opt == "id_player":
		GameState.erd_pk_done = true
		_say_pip("Tepat! id_player unik dan tidak berubah, jadi cocok sebagai primary key.")
		_finish_lesson()
	elif opt == "nama":
		_hint("pk", "Nama bisa kembar. Dua pemain bisa saja bernama sama, jadi nama tidak boleh jadi primary key.")
	else:
		_hint("pk", "Essence terus berubah saat bertarung. Primary key harus tetap dan unik.")
	_refresh.call_deferred()


func _on_card_choice(opt: String) -> void:
	if _finished:
		return
	if opt == "1 : N":
		_rel.setup("1", "N", "memiliki")
		_say_pip("Benar! PLAYER 1 : N SHADE. Foreign key id_player di SHADE menunjuk pemiliknya.")
		_finish_lesson()
	elif opt == "1 : 1":
		_hint("card", "1 : 1 berarti Mira hanya boleh punya satu Shade. Padahal pasukannya banyak.")
	else:
		_hint("card", "N : M berarti satu Shade bisa dimiliki banyak Mira. Padahal tiap Shade hanya milik satu Mira.")
	_refresh.call_deferred()


func _finish_lesson() -> void:
	_finished = true
	var stars: int = 1
	if _hints == 0:
		stars = 3
	elif _hints <= 2:
		stars = 2
	GameState.erd_stars[_mode] = stars
	var reward: int = 3 if _mode == "skill" else 5
	GameState.shards += reward
	if _mode == "split":
		GameState.erd_split_done = true
	_stars_label.text = "Nilai: %d / 3 bintang   (+%d Soul Shard)" % [stars, reward]
	_set_step("done")
	_close_btn.visible = true
	_close_btn.text = "Lanjutkan"
	_refresh.call_deferred()


# ------------------------------------------------------------------ Tampilan isi
func _refresh() -> void:
	_refresh_tray()
	_refresh_player()
	_refresh_shade()
	_rel.visible = _shade_created and (GameState.erd_split_done or _step == "card" or _step == "done")


func _refresh_tray() -> void:
	UI.clear_children(_tray)
	if _mode == "view":
		_tray_title.text = "Kamus ERD"
		for g in GLOSSARY:
			_tray.add_child(UI.label(String(g[0]), 16, UI.GOLD))
			_tray.add_child(UI.wrap_label(String(g[1]), 225.0, 13, UI.MUTED))
		return
	_tray_title.text = "Kartu Atribut"
	var shown: bool = false
	if _mode == "skill" and not GameState.erd_skill_done:
		var c1 := CardScript.new()
		c1.setup("skill", "nilai: Raise  (dari monster pertama)", true, "tray")
		_tray.add_child(c1)
		shown = true
	elif _mode == "split" and not _daftar_in_player and not _shade_created:
		var c2 := CardScript.new()
		c2.setup("daftar_shade", "berisi: %s" % _shade_names(), true, "tray")
		_tray.add_child(c2)
		shown = true
	if not shown:
		_tray.add_child(UI.wrap_label("Tidak ada kartu lagi di sini.", 225.0, 15, UI.MUTED))


func _refresh_player() -> void:
	UI.clear_children(_player_rows)
	var waiting: bool = (_step == "skill" or _step == "daftar")
	var border: Color = UI.GOLD if waiting else Color(0.62, 0.5, 1.0)
	_player_zone.add_theme_stylebox_override("panel", UI.style(Color(0.15, 0.11, 0.26, 1.0), border, 10.0, 3))
	_attr_row(_player_rows, "id_player", "PK" if GameState.erd_pk_done else "")
	_attr_row(_player_rows, "nama", "")
	_attr_row(_player_rows, "hp_maks", "")
	_attr_row(_player_rows, "essence", "")
	if GameState.erd_skill_done:
		_attr_row(_player_rows, "skill  =  Raise", "")
	if _daftar_in_player and not _shade_created:
		var c := CardScript.new()
		c.setup("daftar_shade", "= [%s]" % _shade_names(), true, "entity")
		_player_rows.add_child(c)
		_player_rows.add_child(UI.wrap_label("(satu atribut, banyak nilai)", 225.0, 13, UI.PINK))
	elif waiting:
		_player_rows.add_child(UI.wrap_label("Lepaskan kartu di sini", 225.0, 15, UI.GOLD))


func _refresh_shade() -> void:
	UI.clear_children(_shade_rows)
	if _shade_created:
		_shade_zone.add_theme_stylebox_override("panel", UI.style(Color(0.15, 0.11, 0.26, 1.0), Color(0.62, 0.5, 1.0), 10.0, 3))
		_shade_title.text = "SHADE"
		_attr_row(_shade_rows, "id_shade", "PK")
		_attr_row(_shade_rows, "id_player", "FK")
		_attr_row(_shade_rows, "id_monster", "FK")
		_attr_row(_shade_rows, "nama_panggilan", "")
		_attr_row(_shade_rows, "level", "")
		_attr_row(_shade_rows, "bentuk", "")
	else:
		var wait: bool = (_step == "split")
		var border: Color = UI.GOLD if wait else Color(0.32, 0.27, 0.45)
		_shade_zone.add_theme_stylebox_override("panel", UI.style(Color(0.1, 0.08, 0.17, 1.0), border, 10.0, 3))
		_shade_title.text = "(entitas baru)" if wait else "SHADE (terkunci)"
		if wait:
			_shade_rows.add_child(UI.wrap_label("Lepaskan atribut daftar_shade di sini untuk membuat entitas baru.", 225.0, 15, UI.GOLD))
		else:
			_shade_rows.add_child(UI.wrap_label("Belum ada entitas SHADE. Terbuka setelah daftar_shade dipecah.", 225.0, 14, UI.MUTED))


func _attr_row(parent: Control, text: String, badge: String) -> void:
	var h := HBoxContainer.new()
	var b := UI.label(badge if badge != "" else "", 14, UI.GOLD if badge == "PK" else UI.CYAN)
	b.custom_minimum_size = Vector2(30, 0)
	h.add_child(b)
	h.add_child(UI.label(text, 17, Color.WHITE))
	parent.add_child(h)


func _shade_names() -> String:
	var names: Array = []
	for r in GameState.shade_records:
		var nm: String = String(r["nama"])
		if nm == "":
			nm = String(r["monster"])
		names.append(nm)
	if names.is_empty():
		return "Slime Lumut, ..."
	return ", ".join(names)


# ------------------------------------------------------------------ Tutup
func _on_close() -> void:
	if not _root.visible:
		return
	if _mode != "view" and not _finished:
		return
	_root.visible = false
	closed.emit()


func _input(event: InputEvent) -> void:
	if not _root.visible:
		return
	if event.is_action_pressed("pause"):
		get_viewport().set_input_as_handled()
		_on_close()
	elif event.is_action_pressed("erd_panel") and _mode == "view":
		get_viewport().set_input_as_handled()
		_on_close()

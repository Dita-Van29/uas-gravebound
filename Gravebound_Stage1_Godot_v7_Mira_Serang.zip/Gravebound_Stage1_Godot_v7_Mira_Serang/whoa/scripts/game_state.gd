extends Node
## Autoload "GameState": menyimpan progres antar-stage (Soul Bank, upgrade,
## Soul Shard) dan mendaftarkan semua tombol input lewat kode.

const SAVE_PATH := "user://gravebound_save.json"

# --- Progres run ---
var soul_bank: Dictionary = {}      # id musuh -> jumlah yang pernah berhasil di-Raise
var bank_order: Array = []          # urutan id agar bisa dipanggil lewat tombol 1, 2, ...
var shards: int = 0
var tether_level: int = 1           # tiap level: peluang Raise +5%
var shade_limit: int = 3
var attack_bonus: int = 0
var essence_bonus: float = 0.0      # 0.25 = isi Essence 25% lebih cepat
var shade_shield: bool = false
var stages_cleared: int = 0
var mira_fallen: bool = false       # disiapkan untuk update cerita berikutnya

# --- Fitur edukasi: Mode Desain (ERD) dan Mode Operasi (CRUD) ---
# Tabel SHADE: satu record = satu Shade hasil Raise.
# Kunci record: id (PK), monster (FK ke jenis monster), nama, level, bentuk,
# saved (sudah di-INSERT?), active (sedang bertarung?)
const BANK_CAPACITY := 6
const MAX_LEVEL := 5
var shade_records: Array = []
var next_shade_id: int = 1
var rollback_left: int = 3
var erd_skill_done: bool = false    # atribut skill sudah dipasang ke PLAYER (Raise terbuka)
var erd_pk_done: bool = false       # primary key PLAYER sudah dipilih
var erd_split_done: bool = false    # daftar_shade sudah dipecah menjadi entitas SHADE
var crud_create_done: bool = false  # INSERT pertama sudah dijalankan
var erd_stars: Dictionary = {}      # mode pelajaran -> bintang (1 sampai 3)

# --- Status sesi (tidak disimpan) ---
var restart_area: int = 0
var intro_done: bool = false
var tutorial_done: bool = false


func _ready() -> void:
	_register_inputs()


func new_game() -> void:
	soul_bank = {}
	bank_order = []
	shards = 0
	tether_level = 1
	shade_limit = 3
	attack_bonus = 0
	essence_bonus = 0.0
	shade_shield = false
	stages_cleared = 0
	mira_fallen = false
	shade_records = []
	next_shade_id = 1
	rollback_left = 3
	erd_skill_done = false
	erd_pk_done = false
	erd_split_done = false
	crud_create_done = false
	erd_stars = {}
	restart_area = 0
	intro_done = false
	tutorial_done = false


func bank_add(id: String) -> void:
	if soul_bank.has(id):
		soul_bank[id] = int(soul_bank[id]) + 1
	else:
		soul_bank[id] = 1
		bank_order.append(id)


# ------------------------------------------------------------------ Tabel SHADE (CRUD)
func record_create(monster: String) -> int:
	# Dipanggil saat Raise berhasil: Kartu Record dibuat tetapi BELUM disimpan (belum INSERT).
	var rec := {
		"id": next_shade_id,
		"monster": monster,
		"nama": "",
		"level": 1,
		"bentuk": 1,
		"saved": false,
		"active": true,
	}
	next_shade_id += 1
	shade_records.append(rec)
	return int(rec["id"])


func record_find(id: int) -> int:
	for i in range(shade_records.size()):
		if int(shade_records[i]["id"]) == id:
			return i
	return -1


func record_get(id: int) -> Dictionary:
	var i: int = record_find(id)
	if i >= 0:
		return shade_records[i]
	return {}


func saved_records() -> Array:
	var out: Array = []
	for r in shade_records:
		if bool(r["saved"]):
			out.append(r)
	return out


func pending_records() -> Array:
	var out: Array = []
	for r in shade_records:
		if not bool(r["saved"]):
			out.append(r)
	return out


## INSERT: simpan Kartu Record ke tabel SHADE. Mengembalikan pesan galat, atau "" bila berhasil.
func record_save(id: int, nama: String) -> String:
	var i: int = record_find(id)
	if i < 0:
		return "Kartu Record tidak ditemukan."
	if saved_records().size() >= BANK_CAPACITY:
		return "Soul Bank penuh (%d/%d). Hapus satu baris dengan DELETE dulu." % [BANK_CAPACITY, BANK_CAPACITY]
	var r: Dictionary = shade_records[i]
	r["nama"] = nama
	r["saved"] = true
	crud_create_done = true
	rebuild_bank()
	return ""


## DELETE: hapus satu baris.
func record_delete(id: int) -> void:
	var i: int = record_find(id)
	if i >= 0:
		shade_records.remove_at(i)
	rebuild_bank()


## Dipanggil saat sebuah Shade gugur. Mengembalikan true bila jiwanya lenyap
## (Kartu Record belum di-INSERT sehingga datanya ikut hilang).
func shade_died(id: int) -> bool:
	var i: int = record_find(id)
	if i < 0:
		return false
	var r: Dictionary = shade_records[i]
	r["active"] = false
	if not bool(r["saved"]):
		shade_records.remove_at(i)
		rebuild_bank()
		return true
	return false


func reset_active_flags() -> void:
	for r in shade_records:
		r["active"] = false


## Susun ulang ringkasan Soul Bank (jenis -> jumlah) dari baris yang sudah tersimpan.
func rebuild_bank() -> void:
	var counts: Dictionary = {}
	for r in shade_records:
		if bool(r["saved"]):
			var m: String = String(r["monster"])
			counts[m] = int(counts.get(m, 0)) + 1
	var new_order: Array = []
	for id in bank_order:
		if counts.has(id):
			new_order.append(id)
	for id in counts.keys():
		if not new_order.has(id):
			new_order.append(id)
	bank_order = new_order
	soul_bank = counts


## Gulungan Pembatal (rollback): salinan data sebelum UPDATE atau DELETE.
func snapshot() -> Dictionary:
	return {"records": shade_records.duplicate(true), "shards": shards}


func restore(snap: Dictionary) -> void:
	var recs: Array = snap["records"]
	shade_records = recs.duplicate(true)
	shards = int(snap["shards"])
	rebuild_bank()


func save_game() -> void:
	var data := {
		"soul_bank": soul_bank,
		"bank_order": bank_order,
		"shards": shards,
		"tether_level": tether_level,
		"shade_limit": shade_limit,
		"attack_bonus": attack_bonus,
		"essence_bonus": essence_bonus,
		"shade_shield": shade_shield,
		"stages_cleared": stages_cleared,
		"mira_fallen": mira_fallen,
		"shade_records": shade_records,
		"next_shade_id": next_shade_id,
		"erd_skill_done": erd_skill_done,
		"erd_pk_done": erd_pk_done,
		"erd_split_done": erd_split_done,
		"crud_create_done": crud_create_done,
		"erd_stars": erd_stars,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("Gagal menyimpan: %s" % SAVE_PATH)
		return
	f.store_string(JSON.stringify(data))
	f.close()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func load_game() -> void:
	if not has_save():
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	soul_bank = parsed.get("soul_bank", {})
	bank_order = parsed.get("bank_order", [])
	shards = int(parsed.get("shards", 0))
	tether_level = int(parsed.get("tether_level", 1))
	shade_limit = int(parsed.get("shade_limit", 3))
	attack_bonus = int(parsed.get("attack_bonus", 0))
	essence_bonus = float(parsed.get("essence_bonus", 0.0))
	shade_shield = bool(parsed.get("shade_shield", false))
	stages_cleared = int(parsed.get("stages_cleared", 0))
	mira_fallen = bool(parsed.get("mira_fallen", false))
	next_shade_id = int(parsed.get("next_shade_id", 1))
	erd_skill_done = bool(parsed.get("erd_skill_done", false))
	erd_pk_done = bool(parsed.get("erd_pk_done", false))
	erd_split_done = bool(parsed.get("erd_split_done", false))
	crud_create_done = bool(parsed.get("crud_create_done", false))
	var stars = parsed.get("erd_stars", {})
	erd_stars = stars if typeof(stars) == TYPE_DICTIONARY else {}
	shade_records = []
	var recs = parsed.get("shade_records", [])
	if typeof(recs) == TYPE_ARRAY:
		for r in recs:
			if typeof(r) != TYPE_DICTIONARY:
				continue
			shade_records.append({
				"id": int(r.get("id", 0)),
				"monster": String(r.get("monster", "")),
				"nama": String(r.get("nama", "")),
				"level": int(r.get("level", 1)),
				"bentuk": int(r.get("bentuk", 1)),
				"saved": bool(r.get("saved", false)),
				"active": false,
			})
	# Save lama (sebelum fitur CRUD): ubah penghitung Soul Bank menjadi record yang sudah tersimpan.
	if shade_records.is_empty() and not soul_bank.is_empty():
		for mid in soul_bank.keys():
			for k in range(int(soul_bank[mid])):
				var rid: int = record_create(String(mid))
				var rr: Dictionary = record_get(rid)
				rr["saved"] = true
				rr["active"] = false
				rr["nama"] = "%s %d" % [String(mid), k + 1]
		crud_create_done = true
	for r in shade_records:
		next_shade_id = maxi(next_shade_id, int(r["id"]) + 1)
	rebuild_bank()


# ------------------------------------------------------------------ Input
func _register_inputs() -> void:
	_key("move_left", KEY_A)
	_key("move_left", KEY_LEFT)
	_key("move_right", KEY_D)
	_key("move_right", KEY_RIGHT)
	_key("move_up", KEY_W)
	_key("move_up", KEY_UP)
	_key("move_down", KEY_S)
	_key("move_down", KEY_DOWN)
	_mouse("attack", MOUSE_BUTTON_LEFT)
	_key("attack", KEY_J)
	_key("dash", KEY_SPACE)
	_key("dash", KEY_K)
	_key("raise", KEY_E)
	_key("interact", KEY_E)
	_key("command", KEY_Q)
	_key("soul_link", KEY_R)
	_key("surge", KEY_F)
	_key("summon_1", KEY_1)
	_key("summon_2", KEY_2)
	_key("summon_3", KEY_3)
	_key("advance", KEY_ENTER)
	_key("advance", KEY_KP_ENTER)
	_key("advance", KEY_SPACE)
	_key("advance", KEY_E)
	_key("pause", KEY_ESCAPE)
	_key("toggle_tiltshift", KEY_T)
	_key("erd_panel", KEY_TAB)
	_key("erd_panel", KEY_G)
	_key("crud_console", KEY_B)


func _key(action: String, keycode: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)


func _mouse(action: String, button: MouseButton) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventMouseButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)

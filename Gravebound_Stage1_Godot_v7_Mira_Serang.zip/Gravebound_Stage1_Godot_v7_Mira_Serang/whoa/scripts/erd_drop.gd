extends PanelContainer
## Zona penerima drop (kotak entitas). Semua kartu atribut diterima agar pemain selalu
## mendapat umpan balik; benar/salahnya dinilai oleh drop_fn milik Panel Entitas.

var drop_fn: Callable = Callable()


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	return typeof(data) == TYPE_DICTIONARY and data.has("attr")


func _drop_data(_at_position: Vector2, data: Variant) -> void:
	if drop_fn.is_valid():
		drop_fn.call(data)

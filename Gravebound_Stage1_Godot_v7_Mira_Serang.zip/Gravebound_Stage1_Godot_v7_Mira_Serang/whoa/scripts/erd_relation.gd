extends Control
## Gambar relasi ERD (notasi Chen): garis - belah ketupat berlabel - garis, dengan kardinalitas di ujung.

var left_text: String = "1"
var right_text: String = "N"
var rel_name: String = "memiliki"


func setup(left: String, right: String, name_text: String) -> void:
	left_text = left
	right_text = right
	rel_name = name_text
	custom_minimum_size = Vector2(210, 80)
	queue_redraw()


func _draw() -> void:
	var w: float = size.x
	var cy: float = size.y * 0.5
	var mid: float = w * 0.5
	var col := Color(0.62, 0.5, 1.0)
	draw_line(Vector2(0.0, cy), Vector2(mid - 50.0, cy), col, 3.0)
	draw_line(Vector2(mid + 50.0, cy), Vector2(w, cy), col, 3.0)
	var pts := PackedVector2Array([
		Vector2(mid - 50.0, cy), Vector2(mid, cy - 28.0),
		Vector2(mid + 50.0, cy), Vector2(mid, cy + 28.0),
	])
	draw_colored_polygon(pts, Color(0.2, 0.15, 0.36, 1.0))
	var outline := PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]])
	draw_polyline(outline, col, 3.0)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, Vector2(mid - 44.0, cy + 5.0), rel_name, HORIZONTAL_ALIGNMENT_CENTER, 88.0, 14, Color.WHITE)
	draw_string(font, Vector2(6.0, cy - 8.0), left_text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 20, Color(1.0, 0.85, 0.45))
	draw_string(font, Vector2(w - 22.0, cy - 8.0), right_text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 20, Color(1.0, 0.85, 0.45))

extends CanvasLayer
## KONSOL SOUL BANK - MODE OPERASI (CRUD).
## Tabel SHADE (Soul Bank) dioperasikan lewat empat perintah SQL:
##   Create = INSERT : simpan Kartu Record hasil Raise. Kartu yang belum disimpan LENYAP bila Shade gugur.
##   Read   = SELECT : saring dengan WHERE, lalu panggil Shade ke medan.
##   Update = UPDATE : ganti nama, naikkan level, atau evolve (butuh Soul Shard).
##   Delete = DELETE : hapus baris. Tanpa WHERE, SEMUA baris terhapus. Ada pratinjau baris terdampak.
## Gulungan Pembatal (rollback) membatalkan UPDATE atau DELETE terakhir (jumlahnya terbatas).

signal closed

const UI := preload("res://scripts/ui_kit.gd")

const LEVEL_COST := 4      # Soul Shard untuk naik level = LEVEL_COST x level sekarang
const EVOLVE_COST := 10
const EVOLVE_LEVEL := 3
const NAME_OK := "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 _-"

const TAB_TITLE := {
	"create": "CREATE  -  simpan Kartu Record dengan INSERT",
	"read": "READ  -  baca data dengan SELECT",
	"update": "UPDATE  -  ubah isi baris dengan UPDATE",
	"delete": "DELETE  -  hapus baris dengan DELETE",
}
const TAB_PIP := {
	"create": "INSERT menambah satu baris baru ke tabel. Kartu Record yang belum di-INSERT akan lenyap kalau Shade-nya gugur.",
	"read": "SELECT membaca data. WHERE menyaring baris. Pilih satu baris di tabel lalu panggil Shade-nya ke medan.",
	"update": "UPDATE mengubah isi baris. Selalu pakai WHERE agar hanya baris yang kamu tuju yang berubah.",
	"delete": "DELETE menghapus baris. Tanpa WHERE, SEMUA baris terhapus! Lihat pratinjau 'baris terdampak' sebelum menjalankan.",
}

var stage = null

var _root: ColorRect
var _tab_btns: Dictionary = {}
var _builder: VBoxContainer
var _tree: Tree
var _table_title: Label
var _sql: RichTextLabel
var _status: Label
var _shard_label: Label
var _pip_label: Label
var _rb_btn: Button
var _close_btn: Button

var _tab: String = "create"
var _lesson: bool = false
var _undo: Array = []
var _selected_id: int = -1
var _matches: Array = []

# Kontrol builder (dibuat ulang tiap ganti tab)
var _name_edits: Dictionary = {}
var _where_check: CheckBox = null
var _col_opt: OptionButton = null
var _op_opt: OptionButton = null
var _val_edit: LineEdit = null
var _set_opt: OptionButton = null
var _new_name: LineEdit = null
var _sel_label: Label = null
var _call_btn: Button = null


func _ready() -> void:
	layer = 12
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	_root.visible = false


# ------------------------------------------------------------------ API publik
func is_open() -> bool:
	return _root != null and _root.visible


## Pelajaran Create (tutorial): tutup dikunci sampai INSERT pertama berhasil.
func run_create_lesson() -> void:
	_open("create", true)
	await closed


func open_console() -> void:
	var start: String = "create" if not GameState.pending_records().is_empty() else "read"
	_open(start, false)
	await closed


func _open(tab: String, lesson: bool) -> void:
	_lesson = lesson
	_undo.clear()
	_selected_id = -1
	_matches = []
	_status.text = ""
	_close_btn.disabled = lesson and not GameState.crud_create_done
	_root.visible = true
	_switch_tab(tab)


# ------------------------------------------------------------------ Build UI
func _build() -> void:
	_root = ColorRect.new()
	_root.color = Color(0.02, 0.0, 0.05, 0.84)
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 40)
	margin.add_theme_constant_override("margin_right", 40)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 24)
	_root.add_child(margin)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var main := UI.panel()
	margin.add_child(main)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	main.add_child(col)

	var head := HBoxContainer.new()
	col.add_child(head)
	var title := UI.label("Konsol Soul Bank  -  Mode Operasi (CRUD)", 28, UI.GOLD)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	_shard_label = UI.label("", 18, UI.CYAN)
	head.add_child(_shard_label)

	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	col.add_child(tabs)
	var names := {"create": "Create (INSERT)", "read": "Read (SELECT)", "update": "Update (UPDATE)", "delete": "Delete (DELETE)"}
	for k in ["create", "read", "update", "delete"]:
		var b := UI.button(String(names[k]), Vector2(190, 40), 17)
		b.toggle_mode = true
		b.pressed.connect(_switch_tab.bind(k))
		tabs.add_child(b)
		_tab_btns[k] = b

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 12)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(body)

	var left := UI.panel(Color(0.1, 0.07, 0.18, 1.0), UI.BORDER, 10.0)
	left.custom_minimum_size = Vector2(430, 0)
	body.add_child(left)
	_builder = VBoxContainer.new()
	_builder.add_theme_constant_override("separation", 8)
	left.add_child(_builder)

	var right := UI.panel(Color(0.08, 0.06, 0.15, 1.0), UI.BORDER, 10.0)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(right)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 6)
	right.add_child(rv)
	_table_title = UI.label("Tabel SHADE", 19, UI.CYAN)
	rv.add_child(_table_title)
	_tree = Tree.new()
	_tree.columns = 7
	_tree.column_titles_visible = true
	_tree.hide_root = true
	_tree.select_mode = Tree.SELECT_ROW
	_tree.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tree.custom_minimum_size = Vector2(0, 230)
	_tree.add_theme_font_size_override("font_size", 15)
	_tree.add_theme_font_size_override("title_button_font_size", 15)
	var titles := ["id_shade", "id_monster", "nama_panggilan", "peran", "level", "bentuk", "status"]
	var widths := [70, 110, 150, 70, 55, 60, 80]
	for i in range(titles.size()):
		_tree.set_column_title(i, String(titles[i]))
		_tree.set_column_custom_minimum_width(i, int(widths[i]))
	_tree.item_selected.connect(_on_row_selected)
	rv.add_child(_tree)

	# SQL
	var sql_panel := UI.panel(Color(0.05, 0.03, 0.1, 1.0), Color(0.3, 0.25, 0.5), 8.0)
	col.add_child(sql_panel)
	_sql = RichTextLabel.new()
	_sql.bbcode_enabled = true
	_sql.fit_content = true
	_sql.scroll_active = false
	_sql.custom_minimum_size = Vector2(0, 30)
	_sql.add_theme_font_size_override("normal_font_size", 18)
	sql_panel.add_child(_sql)

	# Pip + status
	var pip_row := HBoxContainer.new()
	pip_row.add_theme_constant_override("separation", 10)
	col.add_child(pip_row)
	var tr := TextureRect.new()
	tr.texture = Util.load_tex("res://assets/sprites/pip.png")
	tr.custom_minimum_size = Vector2(40, 40)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	pip_row.add_child(tr)
	_pip_label = UI.wrap_label("", 700.0, 15, Color(0.95, 0.93, 1.0))
	_pip_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pip_row.add_child(_pip_label)

	var foot := HBoxContainer.new()
	foot.add_theme_constant_override("separation", 10)
	col.add_child(foot)
	_status = UI.wrap_label("", 600.0, 16, UI.GREEN)
	_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	foot.add_child(_status)
	_rb_btn = UI.button("Gulungan Pembatal", Vector2(230, 42), 16)
	_rb_btn.pressed.connect(_on_rollback)
	foot.add_child(_rb_btn)
	_close_btn = UI.button("Tutup (B)", Vector2(150, 42), 16)
	_close_btn.pressed.connect(_on_close)
	foot.add_child(_close_btn)


# ------------------------------------------------------------------ Tab
func _switch_tab(t: String) -> void:
	if _lesson and not GameState.crud_create_done and t != "create":
		_set_status("Selesaikan INSERT pertama dulu.", false)
		_tab_btns[t].set_pressed_no_signal(false)
		return
	_tab = t
	_matches = []
	for k in _tab_btns.keys():
		_tab_btns[k].set_pressed_no_signal(k == t)
	_say_pip(String(TAB_PIP[t]))
	_refresh_all()


func _refresh_all() -> void:
	_build_builder()
	_refresh_table()
	_update_sql()
	_update_header()


func _update_header() -> void:
	_shard_label.text = "Soul Shard: %d" % GameState.shards
	_rb_btn.text = "Gulungan Pembatal (%d)" % GameState.rollback_left
	_rb_btn.disabled = _undo.is_empty() or GameState.rollback_left <= 0
	for k in _tab_btns.keys():
		_tab_btns[k].disabled = _lesson and not GameState.crud_create_done and k != "create"


func _say_pip(text: String) -> void:
	_pip_label.text = text


func _set_status(text: String, ok: bool = true) -> void:
	_status.text = text
	_status.add_theme_color_override("font_color", UI.GREEN if ok else UI.RED)


# ------------------------------------------------------------------ Builder per tab
func _build_builder() -> void:
	UI.clear_children(_builder)
	_name_edits.clear()
	_where_check = null
	_col_opt = null
	_op_opt = null
	_val_edit = null
	_set_opt = null
	_new_name = null
	_sel_label = null
	_call_btn = null
	_builder.add_child(UI.wrap_label(String(TAB_TITLE[_tab]), 400.0, 18, UI.GOLD))
	match _tab:
		"create":
			_build_create()
		"read":
			_build_read()
		"update":
			_build_update()
		"delete":
			_build_delete()


func _build_create() -> void:
	var pend: Array = GameState.pending_records()
	if pend.is_empty():
		_builder.add_child(UI.wrap_label("Tidak ada Kartu Record. Bangkitkan monster dengan E, lalu kembali ke sini untuk menyimpannya.", 400.0, 16, UI.MUTED))
		_builder.add_child(UI.wrap_label("Soul Bank terisi %d / %d baris." % [GameState.saved_records().size(), GameState.BANK_CAPACITY], 400.0, 15, UI.CYAN))
		return
	_builder.add_child(UI.wrap_label("Isi nama panggilan, lalu jalankan INSERT. Soul Bank terisi %d / %d." % [GameState.saved_records().size(), GameState.BANK_CAPACITY], 400.0, 15, UI.CYAN))
	for r in pend:
		var id: int = int(r["id"])
		var box := UI.panel(Color(0.13, 0.1, 0.22, 1.0), Color(0.4, 0.32, 0.68), 8.0)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		box.add_child(v)
		v.add_child(UI.label("Kartu Record #%d  -  %s  (level %d)" % [id, _monster_name(String(r["monster"])), int(r["level"])], 16, UI.CYAN))
		var h := HBoxContainer.new()
		v.add_child(h)
		h.add_child(UI.label("nama_panggilan:  ", 15, Color.WHITE))
		var le := LineEdit.new()
		le.max_length = 16
		le.text = _monster_name(String(r["monster"]))
		le.custom_minimum_size = Vector2(170, 34)
		le.text_changed.connect(_on_builder_changed)
		h.add_child(le)
		_name_edits[id] = le
		var b := UI.button("Jalankan INSERT", Vector2(190, 38), 16)
		b.pressed.connect(_run_insert.bind(id))
		v.add_child(b)
		_builder.add_child(box)


func _build_read() -> void:
	_add_where_builder(false)
	var run := UI.button("Jalankan SELECT", Vector2(200, 40), 16)
	run.pressed.connect(_run_read)
	_builder.add_child(run)
	_sel_label = UI.wrap_label("", 400.0, 15, UI.CYAN)
	_builder.add_child(_sel_label)
	_call_btn = UI.button("Panggil Shade terpilih ke medan", Vector2(300, 40), 16)
	_call_btn.pressed.connect(_run_call)
	_call_btn.disabled = true
	_builder.add_child(_call_btn)
	_update_sel_label()


func _build_update() -> void:
	_builder.add_child(UI.wrap_label("Klik satu baris di tabel (WHERE id_shade = ...), lalu pilih perubahan.", 400.0, 15, UI.MUTED))
	_sel_label = UI.wrap_label("", 400.0, 16, UI.CYAN)
	_builder.add_child(_sel_label)
	_set_opt = OptionButton.new()
	_set_opt.add_item("SET nama_panggilan = ...")
	_set_opt.add_item("SET level = level + 1")
	_set_opt.add_item("SET bentuk = 2  (evolve)")
	_set_opt.custom_minimum_size = Vector2(300, 38)
	_set_opt.item_selected.connect(_on_builder_changed)
	_builder.add_child(_set_opt)
	_new_name = LineEdit.new()
	_new_name.max_length = 16
	_new_name.placeholder_text = "nama baru (maks. 16 huruf)"
	_new_name.custom_minimum_size = Vector2(300, 36)
	_new_name.text_changed.connect(_on_builder_changed)
	_builder.add_child(_new_name)
	_builder.add_child(UI.wrap_label("Biaya: naik level = %d x level sekarang Soul Shard. Evolve = %d Soul Shard dan butuh level %d." % [LEVEL_COST, EVOLVE_COST, EVOLVE_LEVEL], 400.0, 14, UI.MUTED))
	var run := UI.button("Jalankan UPDATE", Vector2(200, 40), 16)
	run.pressed.connect(_run_update)
	_builder.add_child(run)
	_update_sel_label()


func _build_delete() -> void:
	_add_where_builder(true)
	_matches = _compute_matches()
	_sel_label = UI.wrap_label("", 400.0, 16, UI.GOLD)
	_builder.add_child(_sel_label)
	var run := UI.button("Jalankan DELETE", Vector2(200, 40), 16)
	run.pressed.connect(_run_delete)
	_builder.add_child(run)
	_update_sel_label()


func _add_where_builder(default_on: bool) -> void:
	_where_check = CheckBox.new()
	_where_check.text = "Pakai WHERE"
	_where_check.button_pressed = default_on
	_where_check.add_theme_font_size_override("font_size", 16)
	_where_check.toggled.connect(_on_builder_changed)
	_builder.add_child(_where_check)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	_builder.add_child(row)
	_col_opt = OptionButton.new()
	for c in ["peran", "level", "bentuk", "id_monster"]:
		_col_opt.add_item(c)
	_col_opt.custom_minimum_size = Vector2(120, 36)
	_col_opt.item_selected.connect(_on_builder_changed)
	row.add_child(_col_opt)
	_op_opt = OptionButton.new()
	for o in ["=", ">=", "<", "<>"]:
		_op_opt.add_item(o)
	_op_opt.custom_minimum_size = Vector2(70, 36)
	_op_opt.item_selected.connect(_on_builder_changed)
	row.add_child(_op_opt)
	_val_edit = LineEdit.new()
	_val_edit.placeholder_text = "tank / 2 / ..."
	_val_edit.custom_minimum_size = Vector2(150, 36)
	_val_edit.text_changed.connect(_on_builder_changed)
	row.add_child(_val_edit)
	_builder.add_child(UI.wrap_label("Kolom: peran (tank, striker), level, bentuk, id_monster (slime_lumut, tikus_gerogot).", 400.0, 13, UI.MUTED))


func _on_builder_changed(_v = null) -> void:
	if _tab == "delete":
		_matches = _compute_matches()
		_update_sel_label()
		_refresh_table()
	_update_sql()
	if _tab == "update":
		_update_sel_label()


# ------------------------------------------------------------------ Data bantu
func _monster_name(id: String) -> String:
	if stage != null and stage.enemy_db.has(id):
		return String(stage.enemy_db[id].display_name)
	return id


func _role_of(id: String) -> String:
	if stage != null and stage.enemy_db.has(id):
		return String(stage.enemy_db[id].role)
	return "-"


func _cell(rec: Dictionary, col: String):
	if col == "peran":
		return _role_of(String(rec["monster"]))
	if col == "level":
		return int(rec["level"])
	if col == "bentuk":
		return int(rec["bentuk"])
	if col == "id_monster":
		return String(rec["monster"])
	if col == "nama_panggilan":
		return String(rec["nama"])
	return int(rec["id"])


func _where_error() -> String:
	if _where_check == null or not _where_check.button_pressed:
		return ""
	var col: String = _col_opt.get_item_text(_col_opt.selected)
	var raw: String = _val_edit.text.strip_edges()
	if raw == "":
		return "Isi nilai untuk WHERE (contoh: tank atau 2)."
	if (col == "level" or col == "bentuk") and not raw.is_valid_int():
		return "Kolom %s berisi angka. Isi nilai berupa angka." % col
	return ""


func _where_match(rec: Dictionary) -> bool:
	var col: String = _col_opt.get_item_text(_col_opt.selected)
	var op: String = _op_opt.get_item_text(_op_opt.selected)
	var raw: String = _val_edit.text.strip_edges().replace("'", "")
	var left = _cell(rec, col)
	var result: bool = false
	if col == "level" or col == "bentuk":
		if raw.is_valid_int():
			var rv: int = int(raw)
			var lv: int = int(left)
			if op == "=":
				result = lv == rv
			elif op == ">=":
				result = lv >= rv
			elif op == "<":
				result = lv < rv
			else:
				result = lv != rv
	else:
		var ls: String = String(left).to_lower()
		var rs: String = raw.to_lower()
		if op == "=":
			result = ls == rs
		elif op == ">=":
			result = ls >= rs
		elif op == "<":
			result = ls < rs
		else:
			result = ls != rs
	return result


func _compute_matches() -> Array:
	var out: Array = []
	var use_where: bool = _where_check != null and _where_check.button_pressed
	if use_where and _where_error() != "":
		return out
	for r in GameState.saved_records():
		if not use_where or _where_match(r):
			out.append(int(r["id"]))
	return out


func _where_sql() -> String:
	if _where_check == null or not _where_check.button_pressed:
		return ""
	var col: String = _col_opt.get_item_text(_col_opt.selected)
	var op: String = _op_opt.get_item_text(_op_opt.selected)
	var raw: String = _val_edit.text.strip_edges().replace("'", "")
	if raw == "":
		raw = "..."
	var val: String = raw
	if col != "level" and col != "bentuk":
		val = "'%s'" % raw
	return " %s %s %s %s" % [_kw("WHERE"), col, op, val]


func _kw(word: String) -> String:
	return "[color=#ff8fb1]%s[/color]" % word


func _clean_name(raw: String) -> String:
	var out: String = ""
	for ch in raw:
		if NAME_OK.contains(ch):
			out += ch
	return out.strip_edges()


# ------------------------------------------------------------------ Pratinjau SQL
func _update_sql() -> void:
	var t: String = ""
	if _tab == "create":
		var nm: String = "..."
		var mon: String = "..."
		for id in _name_edits.keys():
			var le: LineEdit = _name_edits[id]
			nm = _clean_name(le.text)
			var rec: Dictionary = GameState.record_get(int(id))
			if not rec.is_empty():
				mon = String(rec["monster"])
			break
		t = "%s shade (id_monster, nama_panggilan, level, bentuk) %s ('%s', '%s', 1, 1);" % [_kw("INSERT INTO"), _kw("VALUES"), mon, nm]
	elif _tab == "read":
		t = "%s * %s shade%s;" % [_kw("SELECT"), _kw("FROM"), _where_sql()]
	elif _tab == "update":
		var sid: String = "?"
		if _selected_id >= 0:
			sid = str(_selected_id)
		var setp: String = "bentuk = 2"
		if _set_opt != null and _set_opt.selected == 0:
			setp = "nama_panggilan = '%s'" % _clean_name(_new_name.text)
		elif _set_opt != null and _set_opt.selected == 1:
			setp = "level = level + 1"
		t = "%s shade %s %s %s id_shade = %s;" % [_kw("UPDATE"), _kw("SET"), setp, _kw("WHERE"), sid]
	else:
		t = "%s %s shade%s;" % [_kw("DELETE"), _kw("FROM"), _where_sql()]
	_sql.text = t


func _update_sel_label() -> void:
	if _sel_label == null:
		return
	if _tab == "delete":
		var total: int = GameState.saved_records().size()
		var err: String = _where_error()
		if err != "":
			_sel_label.text = err
		elif _where_check != null and not _where_check.button_pressed:
			_sel_label.text = "AWAS: tanpa WHERE, baris terdampak: %d dari %d (SEMUA baris)!" % [_matches.size(), total]
		else:
			_sel_label.text = "Baris terdampak: %d dari %d" % [_matches.size(), total]
		return
	if _selected_id >= 0:
		var rec: Dictionary = GameState.record_get(_selected_id)
		if not rec.is_empty():
			_sel_label.text = "Terpilih: id_shade %d  (%s)" % [_selected_id, String(rec["nama"])]
			if _call_btn != null:
				_call_btn.disabled = false
			return
	_sel_label.text = "Belum ada baris terpilih. Klik satu baris di tabel."
	if _call_btn != null:
		_call_btn.disabled = true


# ------------------------------------------------------------------ Tabel
func _refresh_table() -> void:
	_tree.clear()
	var root: TreeItem = _tree.create_item()
	var rows: Array = GameState.saved_records()
	_table_title.text = "Tabel SHADE  (%d / %d baris)" % [rows.size(), GameState.BANK_CAPACITY]
	for r in rows:
		var id: int = int(r["id"])
		var it: TreeItem = _tree.create_item(root)
		it.set_text(0, str(id))
		it.set_text(1, String(r["monster"]))
		it.set_text(2, String(r["nama"]))
		it.set_text(3, _role_of(String(r["monster"])))
		it.set_text(4, str(int(r["level"])))
		it.set_text(5, str(int(r["bentuk"])))
		it.set_text(6, "aktif" if bool(r["active"]) else "di bank")
		it.set_metadata(0, id)
		if _matches.has(id):
			var hl: Color = Color(0.5, 0.2, 0.3, 1.0) if _tab == "delete" else Color(0.2, 0.4, 0.35, 1.0)
			for c in range(7):
				it.set_custom_bg_color(c, hl)
		if id == _selected_id:
			it.select(0)


func _on_row_selected() -> void:
	var it: TreeItem = _tree.get_selected()
	if it == null:
		return
	_selected_id = int(it.get_metadata(0))
	_update_sel_label()
	_update_sql()


# ------------------------------------------------------------------ Eksekusi perintah
func _push_undo() -> void:
	_undo.append(GameState.snapshot())
	if _undo.size() > 3:
		_undo.pop_front()


func _run_insert(id: int) -> void:
	var le = _name_edits.get(id, null)
	var nm: String = ""
	if le != null:
		nm = _clean_name(le.text)
	if nm == "":
		_set_status("nama_panggilan tidak boleh kosong (huruf, angka, spasi).", false)
		return
	var err: String = GameState.record_save(id, nm)
	if err != "":
		_set_status(err, false)
		return
	_set_status("INSERT berhasil: 1 baris ditambahkan ke tabel SHADE. Jiwa ini aman di Soul Bank.")
	_say_pip("INSERT berhasil! Sekarang datanya tersimpan. Shade yang gugur kembali ke Soul Bank, tidak lenyap.")
	if _lesson:
		_close_btn.disabled = false
	_refresh_all()


func _run_read() -> void:
	var err: String = _where_error()
	if err != "":
		_set_status(err, false)
		return
	_matches = _compute_matches()
	var total: int = GameState.saved_records().size()
	_set_status("SELECT: %d baris ditemukan dari %d (baris hijau)." % [_matches.size(), total])
	_refresh_table()


func _run_call() -> void:
	if _selected_id < 0 or stage == null:
		_set_status("Pilih satu baris dulu.", false)
		return
	var msg: String = stage.summon_record(_selected_id)
	if msg != "":
		_set_status(msg, false)
	else:
		_set_status("Shade dipanggil ke medan. Tutup konsol untuk bertarung.")
	_refresh_all()


func _run_update() -> void:
	if _selected_id < 0:
		_set_status("Pilih dulu satu baris di tabel (WHERE id_shade = ...).", false)
		return
	var rec: Dictionary = GameState.record_get(_selected_id)
	if rec.is_empty():
		_set_status("Baris tidak ditemukan.", false)
		return
	var mode: int = _set_opt.selected
	if mode == 0:
		var nm: String = _clean_name(_new_name.text)
		if nm == "":
			_set_status("Isi nama baru dulu (huruf, angka, spasi).", false)
			return
		_push_undo()
		rec["nama"] = nm
		_set_status("UPDATE berhasil: 1 baris diubah. nama_panggilan = '%s'." % nm)
	elif mode == 1:
		var lvl: int = int(rec["level"])
		var cost: int = LEVEL_COST * lvl
		if lvl >= GameState.MAX_LEVEL:
			_set_status("Level sudah maksimal (%d)." % GameState.MAX_LEVEL, false)
			return
		if GameState.shards < cost:
			_set_status("Soul Shard kurang: butuh %d, punya %d." % [cost, GameState.shards], false)
			return
		_push_undo()
		GameState.shards -= cost
		rec["level"] = lvl + 1
		_set_status("UPDATE berhasil: level %d -> %d (-%d Soul Shard). Shade jadi lebih kuat." % [lvl, lvl + 1, cost])
	else:
		if int(rec["bentuk"]) >= 2:
			_set_status("Shade ini sudah berevolusi.", false)
			return
		if int(rec["level"]) < EVOLVE_LEVEL:
			_set_status("Evolve butuh level %d. Naikkan level dulu." % EVOLVE_LEVEL, false)
			return
		if GameState.shards < EVOLVE_COST:
			_set_status("Soul Shard kurang: butuh %d, punya %d." % [EVOLVE_COST, GameState.shards], false)
			return
		_push_undo()
		GameState.shards -= EVOLVE_COST
		rec["bentuk"] = 2
		_set_status("UPDATE berhasil: bentuk = 2. Shade berevolusi (HP dan damage naik)!")
	if stage != null:
		stage.refresh_shade(_selected_id)
	_refresh_all()


func _run_delete() -> void:
	var err: String = _where_error()
	if err != "":
		_set_status(err, false)
		return
	var ids: Array = _compute_matches()
	if ids.is_empty():
		_set_status("DELETE: 0 baris terdampak, tidak ada yang dihapus.", false)
		return
	var no_where: bool = _where_check != null and not _where_check.button_pressed
	_push_undo()
	for id in ids:
		if stage != null:
			stage.remove_shade_by_record(int(id))
		GameState.record_delete(int(id))
	_selected_id = -1
	if no_where and ids.size() > 1:
		_set_status("Tanpa WHERE, %d baris ikut terhapus! Pakai Gulungan Pembatal untuk membatalkan." % ids.size(), false)
	else:
		_set_status("DELETE berhasil: %d baris dihapus dari tabel SHADE." % ids.size())
	_refresh_all()


func _on_rollback() -> void:
	if _undo.is_empty():
		_set_status("Belum ada UPDATE atau DELETE yang bisa dibatalkan.", false)
		return
	if GameState.rollback_left <= 0:
		_set_status("Gulungan Pembatal habis.", false)
		return
	var snap: Dictionary = _undo.pop_back()
	GameState.restore(snap)
	GameState.rollback_left -= 1
	if stage != null:
		stage.sync_active_flags()
	_matches = []
	_set_status("Rollback berhasil: perubahan terakhir dibatalkan.")
	_refresh_all()


# ------------------------------------------------------------------ Tutup
func _on_close() -> void:
	if not _root.visible or _close_btn.disabled:
		return
	_root.visible = false
	closed.emit()


func _input(event: InputEvent) -> void:
	if _root.visible and event.is_action_pressed("pause"):
		get_viewport().set_input_as_handled()
		_on_close()


func _unhandled_input(event: InputEvent) -> void:
	# Tombol B menutup konsol. Memakai unhandled agar tidak bentrok saat mengetik di kolom nama.
	if _root.visible and event.is_action_pressed("crud_console"):
		get_viewport().set_input_as_handled()
		_on_close()

extends RefCounted
## Fungsi bantu UI (static) yang dipakai Panel Entitas (ERD) dan Konsol Soul Bank (CRUD).
## Dipanggil lewat: const UI := preload("res://scripts/ui_kit.gd")  ->  UI.label(...)

const GOLD := Color(1.0, 0.85, 0.45)
const CYAN := Color(0.48, 0.88, 0.82)
const PINK := Color(1.0, 0.56, 0.69)
const GREEN := Color(0.6, 1.0, 0.75)
const RED := Color(1.0, 0.5, 0.55)
const MUTED := Color(0.78, 0.74, 0.92)
const BG := Color(0.07, 0.04, 0.13, 0.97)
const BORDER := Color(0.45, 0.35, 0.75, 1.0)


static func label(text: String, size: int = 18, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.02, 0.1))
	l.add_theme_constant_override("outline_size", 4)
	return l


## Label yang membungkus teks panjang otomatis. width = lebar minimum (piksel).
static func wrap_label(text: String, width: float, size: int = 16, color: Color = Color.WHITE) -> Label:
	var l := label(text, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(width, 0.0)
	return l


static func style(bg: Color, border: Color, margin: float = 10.0, width: int = 2) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(width)
	sb.set_corner_radius_all(6)
	sb.set_content_margin_all(margin)
	return sb


static func panel(bg: Color = BG, border: Color = BORDER, margin: float = 10.0) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(bg, border, margin))
	return p


static func button(text: String, min_size: Vector2 = Vector2(160, 40), font_size: int = 16) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	return b


static func clear_children(node: Node) -> void:
	for ch in node.get_children():
		node.remove_child(ch)
		ch.queue_free()

"""Membuat assets/sprites/mira_sheet.png dari tools/source/mira_spritesheet_raw.png.

Spritesheet mentah: grid 19 kolom x 13 baris, sel 208x114 px, latar abu-abu (60,60,60) dengan garis grid kuning/cyan.
Karakter menghadap kanan. Yang dipakai:
  baris mentah 0  kolom 0-8  = idle (9 frame), kolom 9-11 = dash (3 frame)
  baris mentah 4  kolom 0-6  = serangan 1 (7 frame, tebasan merah)
  baris mentah 2  kolom 0-8  = serangan 2 (9 frame, tusukan maju)
  baris mentah 5  kolom 0-11 = serangan 3 (12 frame, tebasan besar penutup combo)
Hasil: grid 12 kolom x 4 baris, tiap frame 180x74 px, kaki rata di dasar frame, dipakai Sprite3D (hframes=12, vframes=4):
  baris 0 = idle + dash, baris 1 = serangan 1, baris 2 = serangan 2, baris 3 = serangan 3.
Jalankan: python3 tools/make_mira_sheet.py   (butuh Pillow dan numpy)
"""
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "tools/source/mira_spritesheet_raw.png"
OUT = ROOT / "assets/sprites/mira_sheet.png"

CELL_W, CELL_H = 208, 114
CROP = (12, 36, 192, 110)        # kotak potong di dalam sel (x0, y0, x1, y1), sama untuk semua frame
COLS = 12
# (baris mentah, jumlah frame) untuk tiap baris hasil
LAYOUT = [(0, 12), (4, 7), (2, 9), (5, 12)]

im = np.array(Image.open(SRC).convert("RGBA"))
r, g, b, a = (im[..., i] for i in range(4))
bg = (r == 60) & (g == 60) & (b == 60) & (a == 255)
line = ((r == 255) & (g == 255) & (b == 0) & (a == 120)) | ((r == 0) & (g == 255) & (b == 255) & (a == 60))
im[bg | line] = (0, 0, 0, 0)
im[..., 3][im[..., 3] > 0] = 255   # sprite dibuat solid penuh (alpha cut)

fw, fh = CROP[2] - CROP[0], CROP[3] - CROP[1]
sheet = Image.new("RGBA", (fw * COLS, fh * len(LAYOUT)), (0, 0, 0, 0))
src = Image.fromarray(im)
clipped = 0
for out_row, (raw_row, n) in enumerate(LAYOUT):
    for c in range(n):
        x0 = c * CELL_W + CROP[0]
        y0 = raw_row * CELL_H + CROP[1]
        # cek apakah ada piksel sprite tepat di tepi kotak potong (tanda terpotong)
        cell = im[y0:y0 + fh, x0:x0 + fw, 3]
        if cell[:, 0].any() or cell[:, -1].any() or cell[0, :].any():
            clipped += 1
            print("PERINGATAN: frame terpotong di tepi", raw_row, c)
        sheet.paste(src.crop((x0, y0, x0 + fw, y0 + fh)), (c * fw, out_row * fh))
sheet.save(OUT)
print("OK", OUT, sheet.size, "frame", (fw, fh), "terpotong:", clipped)
